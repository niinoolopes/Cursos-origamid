<template>
  <p>Página do Usuário: {{$store.state.usuario}}</p>
</template>

<script>
export default {
  name: "Usuario"
};
</script>

<style>
</style>
