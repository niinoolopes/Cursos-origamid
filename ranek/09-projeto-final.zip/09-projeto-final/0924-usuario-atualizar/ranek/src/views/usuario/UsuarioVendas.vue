<template>
  <p>Lista de Vendas</p>
</template>

<script>
export default {};
</script>

<style>
</style>
