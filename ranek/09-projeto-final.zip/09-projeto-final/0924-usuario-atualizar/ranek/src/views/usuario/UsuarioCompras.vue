<template>
  <p>Lista de Compras</p>
</template>

<script>
export default {};
</script>

<style>
</style>
