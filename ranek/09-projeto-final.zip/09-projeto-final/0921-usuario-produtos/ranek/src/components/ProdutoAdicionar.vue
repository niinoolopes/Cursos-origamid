<template>
  <p>Produto Adicionar</p>
</template>

<script>
export default {
  name: "ProdutoAdicionar"
};
</script>

<style>
</style>
