<template>
  <p>Lista de Editar</p>
</template>

<script>
export default {};
</script>

<style>
</style>
