<template>
  <p>Login Criar</p>
</template>

<script>
export default {
  name: "LoginCriar"
};
</script>

<style>
</style>
